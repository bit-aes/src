import React, { useState } from "react";

export default function Counter(props) {
    let [state, setState] = useState({
        value: props.value || 0,
    });

    function increase() {
        setState({
            value: state.value +1
        })
    }

    function decrease() {
        setState({
            value: state.value -1
        })
    }

    return (
        <div class="btn-group" role="group" aria-label="Basic outlined example">
            <button type="button" class="btn btn-outline-primary" onClick={decrease}>
                -
            </button>
            <button type="button" class="btn btn-outline-primary">
                {state.value}
            </button>
            <button type="button" class="btn btn-outline-primary" onClick={increase}>
                +
            </button>
        </div>
    );
}

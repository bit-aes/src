import React from "react";

let PropsPage = function(props) {
    console.log(props)
    return (
            <div>
            {/* Hello {this.props.name} */}
            hello {props.name}
            </div>
    )
}

export default PropsPage;
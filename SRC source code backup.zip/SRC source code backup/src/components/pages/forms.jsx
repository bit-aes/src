import React, { useState } from "react";

export default function FormPage(props) {
    let [state, setState] = useState({
        name: ""
    });

    function updateName(event) {
        setState({
            name: event.target.value
        })
    }

    return (
        <div class="container-sm">
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">
                    Hello {JSON.stringify(state)}
                </label>
                <input
                    type="email"
                    class="form-control"
                    id="exampleFormControlInput1"
                    placeholder="name@example.com"
                    onChange={updateName}
                ></input>
            </div>
        </div>
    );
}

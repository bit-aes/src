import FormPage from "./components/pages/forms";
import PropsPage from "./components/pages/propspage";
import StatePage from "./components/pages/statePage";
import { Route, Link, Routes, Navigate } from "react-router-dom";

function App() {
  return (
    <div>
      <nav class="navbar navbar-expand-lg bg-light">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Navbar</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <Link to="/props" >
                  <a class="nav-link active" aria-current="page">Props</a>
                </Link>
              </li>
              <li class="nav-item">
                <Link to="/from" >
                  <a class="nav-link active" aria-current="page">Forms</a>
                </Link>
              </li>
              <li class="nav-item">
                <Link to="/state" >
                <a class="nav-link active" aria-current="page">State</a>
              </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <Routes>
        <Route path={'/'} element={<Navigate to="/props" />} />
        <Route path={'*'} element={<Navigate to="/props" />} />
        <Route path={'/props'} element={<PropsPage />} />
        <Route path={'/from'} element={<FormPage />} />
        <Route path={'/state'} element={<StatePage />} />
      </Routes>
    </div>
  );
}

export default App;
